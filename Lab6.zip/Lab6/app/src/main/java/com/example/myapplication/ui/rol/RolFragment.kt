package com.example.myapplication.ui.rol

import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController

import com.example.myapplication.R
import com.example.myapplication.database.ZeventDataBase
import com.example.myapplication.databinding.RolFragmentBinding

class RolFragment : Fragment() {

    private lateinit var rolViewModel: RolViewModel
    private lateinit var binding: RolFragmentBinding
    private lateinit var rolViewModelFactory: RolViewModelFactory

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = DataBindingUtil.inflate(inflater, R.layout.rol_fragment, container, false)

        setHasOptionsMenu(true)

        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        binding.lifecycleOwner = this
        val application = requireNotNull(this.activity).application
        val dataSource = ZeventDataBase.getInstance(application).zeventDao
        rolViewModelFactory = RolViewModelFactory(dataSource)
        rolViewModel =
            ViewModelProvider(this, rolViewModelFactory).get(RolViewModel::class.java)
        binding.rolViewModel = rolViewModel
        binding.addrol.setOnClickListener {

            it.findNavController().navigate(R.id.action_rolFragment_to_addRolFragment)
        }



    }
}
