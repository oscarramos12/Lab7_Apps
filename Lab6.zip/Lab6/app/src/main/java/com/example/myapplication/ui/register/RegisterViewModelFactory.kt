package com.example.myapplication.ui.register

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.myapplication.database.Register
import com.example.myapplication.database.ZeventDao
import com.example.myapplication.database.ZeventDataBase
import java.lang.IllegalArgumentException
import javax.sql.CommonDataSource

public class RegisterViewModelFactory(private val database: ZeventDao):ViewModelProvider.Factory{
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if(modelClass.isAssignableFrom(RegisterViewModel::class.java))
            return RegisterViewModel(database) as T
        throw IllegalArgumentException("Unknown ViewModel Class")

    }



}