package com.example.myapplication.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface ZeventDao {

    @Insert
    fun insert(register: Register)
    @Update
    fun update(register: Register)
    @Query("SELECT * FROM register_table WHERE registerId=:key")
    fun get(key:Long):Register
    @Query("DELETE FROM register_table")
    fun clear()
    @Query("SELECT * FROM register_table ORDER BY registerId DESC LIMIT 1")
    fun getRegister():Register
    @Query("SELECT * FROM register_table ORDER BY registerId DESC")
    fun getAllRegister():LiveData<List<Register>>
    @Query ("SELECT name FROM register_table")
    fun getName():String

    @Insert
    fun insertRol(rol: Rol)
    @Update
    fun updateRol(rol: Rol)
    @Query("SELECT * FROM rol_table WHERE rolId=:key")
    fun getRol(key:Long):Rol
    @Query("DELETE FROM rol_table")
    fun clearRol()
    @Query("SELECT * FROM rol_table ORDER BY rolId DESC LIMIT 1")
    fun getRols():Rol
    @Query("SELECT * FROM rol_table ORDER BY rolId DESC")
    fun getAllRol():LiveData<List<Rol>>

}