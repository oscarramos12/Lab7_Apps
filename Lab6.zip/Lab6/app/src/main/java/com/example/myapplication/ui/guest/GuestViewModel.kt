package com.example.myapplication.ui.guest

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import com.example.myapplication.database.Register
import com.example.myapplication.database.ZeventDao
import kotlinx.coroutines.*
import java.lang.StringBuilder

class GuestViewModel (val database: ZeventDao): ViewModel() {

    private var viewModelJob= Job()
    private val uiScope= CoroutineScope(Dispatchers.Main+viewModelJob)
    private var register= MutableLiveData<Register>()
    private var allRegister=database.getAllRegister()
    val regist= Transformations.map(allRegister){
        getAll(it)
    }
    private fun getAll(names:List<Register>):String {


        val allRegist= StringBuilder()


        for (name in names)
            allRegist.append("Nombre: ${name.name}\n Numero: ${name.number}\n Mail: ${name.mail}\n Rol: ${name.rol}\n\n\n")

        return allRegist.toString()



    }
    override fun onCleared(){

        super.onCleared()
        viewModelJob.cancel()
    }

}