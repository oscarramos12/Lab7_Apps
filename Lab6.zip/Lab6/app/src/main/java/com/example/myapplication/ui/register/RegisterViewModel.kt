package com.example.myapplication.ui.register

import android.app.Application
import android.provider.SyncStateContract.Helpers.insert
import androidx.lifecycle.*
import com.example.myapplication.database.Register
import com.example.myapplication.database.Rol
import com.example.myapplication.database.ZeventDao
import com.example.myapplication.database.ZeventDataBase
import kotlinx.coroutines.*
import java.lang.StringBuilder

class RegisterViewModel(val database:ZeventDao): ViewModel() {

    private var viewModelJob= Job()
    private val uiScope= CoroutineScope(Dispatchers.Main+viewModelJob)
    private var register= MutableLiveData<Register>()
    private var allRol= database.getAllRol()
    private var allRregister=database.getAllRegister()
    val nametext=Transformations.map(allRregister){
        getName(it)
    }
    val numbertext=Transformations.map(allRregister){
        getNumber(it)
    }
    val mailtext=Transformations.map(allRregister){
        getMail(it)
    }

    val rol= Transformations.map(allRregister){

        getRol(it)
    }
    init {
        initializeRegister()
    }
    private fun initializeRegister(){
        uiScope.launch {
            register.value= getRegisterFromDataBase()
        }
    }

    private suspend fun getRegisterFromDataBase():Register{
        return withContext(Dispatchers.IO){
            var registers=database.getRegister()
            registers
        }
    }
    private fun getName(names:List<Register>):String {
        val allNames=StringBuilder()

        for (name in names)
            allNames.append("Nombre: ${name.name}"+",")

        return allNames.split(",")[0]

    }
    private fun getMail(mails:List<Register>):String {


        val allMails=StringBuilder()

        for (mail in mails)
            allMails.append("Correo: ${mail.mail}"+",")

        val ulti = allMails.split(",")

        val lol = ulti[0]
        return lol

    }
    private fun getNumber(numbers:List<Register>):String {


        val allNumber=StringBuilder()


        for (number in numbers)
            allNumber.append("Numero: ${number.number}"+",")

        return allNumber.split(",")[0]



    }

    private fun getRol(rol:List<Register>):String {

        val allRol=StringBuilder()

        for (rols in rol)
            allRol.append("Rol: ${rols.rol}"+",")

        return allRol.split(",")[0]

    }

    override fun onCleared(){

        super.onCleared()
        viewModelJob.cancel()
    }
    }




