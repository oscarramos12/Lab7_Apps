package com.example.myapplication.ui.guest

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import com.example.myapplication.R
import com.example.myapplication.database.ZeventDataBase
import com.example.myapplication.databinding.FragmentGuestBinding

class GuestFragment : Fragment() {

    private lateinit var guestViewModel: GuestViewModel
    private lateinit var binding: FragmentGuestBinding
    private lateinit var guestViewModelFactory: GuestViewModelFactory

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        //val root = inflater.inflate(R.layout.fragment_add, container, false)


        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_guest, container, false)




        setHasOptionsMenu(true)

        return binding.root
    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        binding.lifecycleOwner=this
        val application= requireNotNull(this.activity).application
        val dataSource=ZeventDataBase.getInstance(application).zeventDao
        guestViewModelFactory= GuestViewModelFactory(dataSource)
        guestViewModel=ViewModelProvider(this, guestViewModelFactory).get(GuestViewModel::class.java)
        binding.guestViewModel=guestViewModel
        binding.addButton.setOnClickListener { v: View ->

            v.findNavController().navigate(R.id.action_guestFragment_to_addFragment)

        }

    }

}