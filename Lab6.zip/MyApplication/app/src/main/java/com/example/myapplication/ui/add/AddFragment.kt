package com.example.myapplication.ui.add

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
//import androidx.lifecycle.ViewModelProviders
import androidx.navigation.findNavController
import com.example.myapplication.R
import com.example.myapplication.database.ZeventDataBase
import com.example.myapplication.databinding.FragmentAddBinding




public class AddFragment : Fragment() {
    companion object {
        fun newInstance() = AddFragment()
    }

    private lateinit var addViewModel: AddViewModel
    private lateinit var binding: FragmentAddBinding
    private lateinit var addViewModelFactory: AddViewModelFactory


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {


        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_add, container, false)




        setHasOptionsMenu(true)

        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        binding.lifecycleOwner=this
        val application= requireNotNull(this.activity).application
        val dataSource=ZeventDataBase.getInstance(application).zeventDao
        addViewModelFactory= AddViewModelFactory(dataSource)
        addViewModel=ViewModelProvider(this, addViewModelFactory).get(AddViewModel::class.java)
        binding.addViewModel= addViewModel
        binding.saveButton.setOnClickListener { v: View ->

            v.findNavController().navigate(R.id.action_addFragment_to_registerFragment)
            addViewModel.insertRegister()
        }

    }
    }

